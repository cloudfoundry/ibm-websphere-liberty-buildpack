# Copyright IBM Corp. 2012, 2013
# The source code for this program is not published or other-
# wise divested of its trade secrets, irrespective of what has
# been deposited with the U.S. Copyright Office.

import java
import javax.management
import javax.management.remote
import jarray
import com.ibm.ws.jmx.connector.client.rest

class BaseNotificationListener(javax.management.NotificationListener):
	# The client applications can subclass BaseNotificationListener, and
	# override handleNotification() method. 
	def __init__(self):
		pass

	def handleNotification(self,notification,handback):
		# A user can override this method.
		pass

class BaseNotificationFilter(javax.management.NotificationFilter):
	# The client applications can subclass BaseNotificationFilter, and
	# override isNotificationEnabled() method. 
		
	def __init__(self):
		pass

	def isNotificationEnabled(self,notification):
		# A user can override this method.
		return True
		
class JMXRESTConnector(object):
	connector = None
	mbeanConnection = None
	trustStore = None
	trustStorePassword = None

	def __init__(self):
		pass

	def connect(self,host,port,*args):
		if len(args)==2:
			self.connectBasic(host,port,args[0],args[1])
		else:
			self.connectAdvanced(host,port,args[0])

	def connectAdvanced(self,host,port,map):
		print "Connecting to the server..."
		java.lang.System.setProperty("javax.net.ssl.trustStore",self.trustStore)
		java.lang.System.setProperty("javax.net.ssl.trustStorePassword",self.trustStorePassword)
		url=javax.management.remote.JMXServiceURL("REST",host,port,"/IBMJMXConnectorREST")
		self.connector=javax.management.remote.JMXConnectorFactory.newJMXConnector(url,map)
		self.connector.connect()
		print "Successfully connected to the server " + '"' + host + ':%i"' % port

	def connectBasic(self,host,port,user,password):
		map=java.util.HashMap()
		map.put("jmx.remote.provider.pkgs","com.ibm.ws.jmx.connector.client")
		map.put(javax.management.remote.JMXConnector.CREDENTIALS,jarray.array([user,password],java.lang.String))
		map.put(com.ibm.ws.jmx.connector.client.rest.ClientProvider.READ_TIMEOUT,2*60*1000)
		map.put(com.ibm.websphere.jmx.connector.rest.ConnectorSettings.DISABLE_HOSTNAME_VERIFICATION, True) 
		self.connectAdvanced(host,port,map)

	def disconnect(self):
		if(self.connector==None):
			pass
		else:
			self.connector.close()
			self.connector = None
			self.mbeanConnection = None

	def getMBeanServerConnection(self):
		# This method can be called after the above connect() is executed successfully.
		self.mbeanConnection=self.connector.getMBeanServerConnection()
		return self.mbeanConnection





